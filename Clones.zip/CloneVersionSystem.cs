﻿namespace Clones;

public class CloneVersionSystem : ICloneVersionSystem
{
	public string Execute(string query)
	{
		return null;
	}
}